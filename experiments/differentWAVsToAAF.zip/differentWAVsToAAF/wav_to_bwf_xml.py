#!/usr/bin/env python3
"""
WAV to BWF + XML Converter for Media Composer 2025.6.0
======================================================

Creates Broadcast Wave Format files with embedded metadata
and XML project files for reliable Avid import across versions.

This approach is more compatible than AAF for modern Media Composer.
"""

import os
import sys
import wave
import struct
from datetime import datetime

def get_wav_info(wav_path):
    """Extract audio information from WAV file."""
    try:
        with wave.open(wav_path, 'rb') as wav_file:
            return {
                'channels': wav_file.getnchannels(),
                'sample_width': wav_file.getsampwidth(),
                'sample_rate': wav_file.getframerate(),
                'frame_count': wav_file.getnframes(),
                'duration_seconds': wav_file.getnframes() / wav_file.getframerate(),
                'format_tag': 1  # PCM
            }
    except Exception as e:
        raise Exception(f"Error reading WAV file: {e}")

def create_bext_chunk(wav_info, filename):
    """
    Create BWF (Broadcast Wave Format) BEXT chunk with metadata.
    This is what makes it compatible with Avid systems.
    """
    # BWF BEXT chunk structure
    description = f"Audio: {filename}".ljust(256, '\0')[:256]
    originator = "WAV to BWF Converter".ljust(32, '\0')[:32] 
    originator_reference = filename.ljust(32, '\0')[:32]
    origination_date = datetime.now().strftime("%Y-%m-%d").ljust(10, '\0')[:10]
    origination_time = datetime.now().strftime("%H:%M:%S").ljust(8, '\0')[:8]
    
    # Time reference (samples since midnight)
    time_reference_low = 0
    time_reference_high = 0
    
    # BWF version
    version = 1
    
    # UMID (Unique Material Identifier) - 64 bytes of zeros for simplicity
    umid = b'\0' * 64
    
    # Loudness info (16 bytes of zeros)
    loudness_value = 0
    loudness_range = 0  
    max_true_peak_level = 0
    max_momentary_loudness = 0
    max_short_term_loudness = 0
    reserved = b'\0' * 180
    
    # Coding history
    coding_history = f"A=PCM,F={wav_info['sample_rate']},W={wav_info['sample_width']*8},M={'stereo' if wav_info['channels']==2 else 'mono'},T=WAV to BWF Converter\r\n"
    
    # Pack the BEXT chunk
    bext_data = (
        description.encode('utf-8')[:256] +
        originator.encode('utf-8')[:32] +
        originator_reference.encode('utf-8')[:32] +
        origination_date.encode('utf-8')[:10] +
        origination_time.encode('utf-8')[:8] +
        struct.pack('<Q', time_reference_low + (time_reference_high << 32)) +
        struct.pack('<H', version) +
        umid +
        struct.pack('<H', loudness_value) +
        struct.pack('<H', loudness_range) +
        struct.pack('<H', max_true_peak_level) +
        struct.pack('<H', max_momentary_loudness) +
        struct.pack('<H', max_short_term_loudness) +
        reserved +
        coding_history.encode('utf-8')
    )
    
    # Pad to even length
    if len(bext_data) % 2:
        bext_data += b'\0'
    
    return bext_data

def convert_wav_to_bwf(wav_path, bwf_path):
    """
    Convert WAV to BWF (Broadcast Wave Format) for Avid compatibility.
    """
    print(f"Converting {os.path.basename(wav_path)} to BWF...")
    
    wav_info = get_wav_info(wav_path)
    filename = os.path.splitext(os.path.basename(wav_path))[0]
    
    # Read original WAV file
    with open(wav_path, 'rb') as wav_file:
        wav_data = wav_file.read()
    
    # Find the data chunk
    riff_header = wav_data[:12]  # RIFF + size + WAVE
    chunks_data = wav_data[12:]
    
    # Create BWF BEXT chunk
    bext_chunk_data = create_bext_chunk(wav_info, filename)
    bext_chunk = b'bext' + struct.pack('<I', len(bext_chunk_data)) + bext_chunk_data
    
    # Write BWF file
    with open(bwf_path, 'wb') as bwf_file:
        # Write RIFF header
        bwf_file.write(riff_header)
        
        # Write BEXT chunk first (BWF requirement)
        bwf_file.write(bext_chunk)
        
        # Write remaining chunks
        bwf_file.write(chunks_data)
    
    # Update file size in RIFF header
    file_size = os.path.getsize(bwf_path) - 8
    with open(bwf_path, 'r+b') as bwf_file:
        bwf_file.seek(4)
        bwf_file.write(struct.pack('<I', file_size))
    
    print(f"✓ BWF created: {bwf_path}")
    print(f"✓ Added BWF metadata for Avid compatibility")
    return True

def create_avid_xml(bwf_path, xml_path):
    """
    Create Avid Media Composer compatible XML project file.
    """
    print(f"Creating Avid XML project file...")
    
    wav_info = get_wav_info(bwf_path)  # BWF has same audio structure as WAV
    filename = os.path.splitext(os.path.basename(bwf_path))[0]
    
    # Create XML content for Avid Media Composer
    xml_content = f"""<?xml version="1.0" encoding="UTF-8"?>
<xmeml version="5">
    <project>
        <name>{filename}_Project</name>
        <children>
            <bin>
                <name>Audio</name>
                <children>
                    <clip id="clip1">
                        <name>{filename}</name>
                        <duration>{int(wav_info['duration_seconds'] * 24)}</duration>
                        <rate>
                            <timebase>24</timebase>
                        </rate>
                        <media>
                            <audio>
                                <samplecharacteristics>
                                    <depth>{wav_info['sample_width'] * 8}</depth>
                                    <samplerate>{wav_info['sample_rate']}</samplerate>
                                </samplecharacteristics>
                                <channelcount>{wav_info['channels']}</channelcount>
                                <audiochannel>
                                    <file>
                                        <name>{os.path.basename(bwf_path)}</name>
                                        <pathurl>file://localhost{os.path.abspath(bwf_path)}</pathurl>
                                    </file>
                                </audiochannel>
                            </audio>
                        </media>
                    </clip>
                </children>
            </bin>
        </children>
    </project>
</xmeml>"""
    
    with open(xml_path, 'w', encoding='utf-8') as xml_file:
        xml_file.write(xml_content)
    
    print(f"✓ Avid XML created: {xml_path}")
    return True

def main():
    """Main conversion function."""
    print("WAV to BWF + XML Converter for Media Composer 2025.6.0")
    print("=" * 60)
    
    # Test file
    wav_file = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2.wav"
    
    if not os.path.exists(wav_file):
        print(f"ERROR: File not found: {wav_file}")
        return
    
    # Generate output filenames
    wav_dir = os.path.dirname(wav_file)
    wav_name = os.path.splitext(os.path.basename(wav_file))[0]
    bwf_file = os.path.join(wav_dir, f"{wav_name}.bwf")
    xml_file = os.path.join(wav_dir, f"{wav_name}_Project.xml")
    
    try:
        # Convert to BWF
        if convert_wav_to_bwf(wav_file, bwf_file):
            print("✓ BWF conversion successful")
        
        # Create XML project
        if create_avid_xml(bwf_file, xml_file):
            print("✓ XML project creation successful")
        
        print("\n" + "="*60)
        print("CONVERSION COMPLETE!")
        print("="*60)
        print(f"BWF File: {os.path.basename(bwf_file)}")
        print(f"XML File: {os.path.basename(xml_file)}")
        print()
        print("IMPORT INSTRUCTIONS for Media Composer 2025.6.0:")
        print("1. Open Media Composer")
        print("2. File > Import...")
        print(f"3. Select: {os.path.basename(xml_file)}")
        print("4. The BWF audio will import with proper metadata")
        print()
        print("This method is more reliable than AAF for MC 2025.6.0!")
        
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()