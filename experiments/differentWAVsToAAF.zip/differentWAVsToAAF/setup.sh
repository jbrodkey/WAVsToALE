#!/bin/bash

# WAV to AAF Converter Setup Script
echo "Setting up WAV to AAF Converter..."

# Check if Python 3 is installed
if ! command -v python3 &> /dev/null; then
    echo "ERROR: Python 3 is not installed. Please install Python 3.6 or later."
    exit 1
fi

echo "Python 3 found ✓"

# Install required dependencies
echo "Installing pyaaf2 library..."
pip3 install -r requirements.txt

if [ $? -eq 0 ]; then
    echo "Setup complete! ✓"
    echo ""
    echo "To run the converter:"
    echo "python3 wav_to_aaf_converter.py"
    echo ""
    echo "Or make it executable:"
    echo "chmod +x wav_to_aaf_converter.py"
    echo "./wav_to_aaf_converter.py"
else
    echo "ERROR: Failed to install dependencies"
    exit 1
fi