#!/usr/bin/env python3
"""
AAF Validation Script
====================

Simple script to test and validate AAF files before importing into Media Composer.
"""

import sys
import os
import aaf2

def validate_aaf(aaf_path):
    """
    Validate an AAF file by attempting to read its structure.
    
    Args:
        aaf_path (str): Path to AAF file to validate
    """
    try:
        print(f"Validating AAF file: {os.path.basename(aaf_path)}")
        print("-" * 50)
        
        with aaf2.open(aaf_path, 'r') as aaf_file:
            print("✓ AAF file opens successfully")
            
            # Check header
            header = aaf_file.header
            print(f"✓ Header found")
            
            # Check content
            content = aaf_file.content
            print(f"✓ Content storage found")
            
            # List mobs
            mobs = list(content.mobs)
            print(f"✓ Found {len(mobs)} mob(s)")
            
            for i, mob in enumerate(mobs):
                print(f"  Mob {i+1}: {mob.name} ({mob.__class__.__name__})")
                
                # Check slots
                slots = list(mob.slots)
                print(f"    Slots: {len(slots)}")
                
                for j, slot in enumerate(slots):
                    print(f"      Slot {j+1}: {slot.name} ({slot.media_kind})")
                    if hasattr(slot, 'segment') and slot.segment:
                        print(f"        Segment: {slot.segment.__class__.__name__}")
                        if hasattr(slot.segment, 'length'):
                            print(f"        Length: {slot.segment.length}")
            
            # Check essence data
            essence_data = list(content.essencedata)
            print(f"✓ Found {len(essence_data)} essence data object(s)")
            
            for i, essence in enumerate(essence_data):
                print(f"  Essence {i+1}: {essence.mob_id}")
            
            print("\n✓ AAF validation successful!")
            return True
            
    except Exception as e:
        print(f"✗ AAF validation failed: {e}")
        return False

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 validate_aaf.py <aaf_file>")
        sys.exit(1)
    
    aaf_path = sys.argv[1]
    
    if not os.path.exists(aaf_path):
        print(f"Error: File not found: {aaf_path}")
        sys.exit(1)
    
    if not aaf_path.lower().endswith('.aaf'):
        print(f"Warning: File doesn't have .aaf extension")
    
    success = validate_aaf(aaf_path)
    sys.exit(0 if success else 1)

if __name__ == "__main__":
    main()