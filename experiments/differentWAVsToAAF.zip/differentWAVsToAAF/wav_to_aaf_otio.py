#!/usr/bin/env python3
"""
WAV to AAF Converter using OpenTimelineIO
=========================================

Modern approach using OTIO (used by Pixar, Netflix, etc.)
for better Media Composer 2025.6.0 compatibility.

"""

import os
import sys
import wave
import opentimelineio as otio

def get_wav_info(wav_path):
    """Extract audio information from WAV file."""
    try:
        with wave.open(wav_path, 'rb') as wav_file:
            return {
                'channels': wav_file.getnchannels(),
                'sample_width': wav_file.getsampwidth(),
                'sample_rate': wav_file.getframerate(),
                'frame_count': wav_file.getnframes(),
                'duration_seconds': wav_file.getnframes() / wav_file.getframerate()
            }
    except Exception as e:
        raise Exception(f"Error reading WAV file: {e}")

def create_aaf_with_otio(wav_path, aaf_path):
    """
    Create AAF using OpenTimelineIO for modern compatibility.
    """
    print(f"Converting {os.path.basename(wav_path)} to AAF using OTIO...")
    
    # Get WAV file information
    wav_info = get_wav_info(wav_path)
    print(f"WAV Info: {wav_info['channels']} channels, {wav_info['sample_rate']} Hz, "
          f"{wav_info['duration_seconds']:.2f} seconds")
    
    # Create timeline with professional frame rate
    timeline = otio.schema.Timeline(
        name=os.path.splitext(os.path.basename(wav_path))[0],
        global_start_time=otio.opentime.RationalTime(0, 24)  # 24fps
    )
    
    # Create audio track
    audio_track = otio.schema.Track(
        name="Audio_1",
        kind=otio.schema.TrackKind.Audio
    )
    
    # Create media reference for the WAV file
    media_ref = otio.schema.ExternalReference(
        target_url=f"file://{os.path.abspath(wav_path)}"
    )
    
    # Create clip with proper timing
    duration_in_frames = int(wav_info['duration_seconds'] * 24)  # 24fps
    clip = otio.schema.Clip(
        name=os.path.splitext(os.path.basename(wav_path))[0],
        media_reference=media_ref,
        source_range=otio.opentime.TimeRange(
            start_time=otio.opentime.RationalTime(0, 24),
            duration=otio.opentime.RationalTime(duration_in_frames, 24)
        )
    )
    
    # Add clip to track
    audio_track.append(clip)
    
    # Add track to timeline
    timeline.tracks.append(audio_track)
    
    # Write AAF using OTIO
    try:
        otio.adapters.write_to_file(timeline, aaf_path)
        print(f"✓ OTIO AAF created successfully: {aaf_path}")
        print(f"Duration: {wav_info['duration_seconds']:.2f} seconds")
        print(f"Frame rate: 24 fps")
        print("Ready for import into Media Composer 2025.6.0")
        return True
    except Exception as e:
        print(f"OTIO AAF creation failed: {e}")
        return False

def main():
    """Main function to run the OTIO WAV to AAF converter."""
    print("WAV to AAF Converter using OpenTimelineIO")
    print("=" * 50)
    
    # Test file
    wav_file = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2.wav"
    
    if not os.path.exists(wav_file):
        print(f"ERROR: File not found: {wav_file}")
        return
    
    # Generate AAF filename
    wav_dir = os.path.dirname(wav_file)
    wav_name = os.path.splitext(os.path.basename(wav_file))[0]
    aaf_file = os.path.join(wav_dir, f"{wav_name}_OTIO.aaf")
    
    try:
        success = create_aaf_with_otio(wav_file, aaf_file)
        if success:
            print("Conversion completed successfully!")
            print(f"Output: {os.path.basename(aaf_file)}")
        else:
            print("Conversion failed!")
            
    except Exception as e:
        print(f"ERROR: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()