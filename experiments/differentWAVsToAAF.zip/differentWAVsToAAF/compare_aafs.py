#!/usr/bin/env python3
"""
AAF Comparison Tool
==================

Compares generated AAF structure against the reference AAF from Avid.
"""

import aaf2
import os

def analyze_aaf_brief(aaf_path, label):
    """
    Quick analysis of AAF structure for comparison.
    """
    print(f"\n{label}: {os.path.basename(aaf_path)}")
    print("=" * 60)
    
    try:
        with aaf2.open(aaf_path, 'r') as aaf_file:
            content = aaf_file.content
            mobs = list(content.mobs)
            essence_list = list(content.essencedata)
            
            print(f"Total mobs: {len(mobs)}")
            print(f"Total essence data: {len(essence_list)}")
            
            for i, mob in enumerate(mobs):
                print(f"\nMOB {i+1}: {mob.__class__.__name__}")
                print(f"  Name: '{mob.name}'")
                print(f"  MobID: {str(mob.mob_id)[:50]}...")
                
                if hasattr(mob, 'descriptor') and mob.descriptor:
                    desc = mob.descriptor
                    print(f"  Descriptor: {desc.__class__.__name__}")
                
                slots = list(mob.slots)
                print(f"  Slots: {len(slots)}")
                
                for j, slot in enumerate(slots):
                    print(f"    Slot {j+1}: {slot.__class__.__name__} (ID: {slot.slot_id})")
                    print(f"      Name: '{slot.name}'")
                    print(f"      Media Kind: {slot.media_kind}")
                    print(f"      Edit Rate: {getattr(slot, 'edit_rate', 'N/A')}")
                    
                    if hasattr(slot, 'segment') and slot.segment:
                        seg = slot.segment
                        print(f"      Segment: {seg.__class__.__name__}")
                        if hasattr(seg, 'length'):
                            print(f"        Length: {seg.length}")
                        if hasattr(seg, 'mob_id'):
                            print(f"        References: {str(seg.mob_id)[:30]}...")
            
            for i, essence in enumerate(essence_list):
                print(f"\nESSENCE {i+1}: {str(essence.mob_id)[:50]}...")
                
    except Exception as e:
        print(f"ERROR analyzing {label}: {e}")

def compare_aafs():
    """
    Compare reference AAF vs generated AAF
    """
    reference_path = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2-exportedEmbeddedAAF.aaf"
    generated_path = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2.aaf"
    
    if not os.path.exists(reference_path):
        print(f"Reference AAF not found: {reference_path}")
        return False
        
    if not os.path.exists(generated_path):
        print(f"Generated AAF not found: {generated_path}")
        return False
    
    analyze_aaf_brief(reference_path, "REFERENCE (Avid)")
    analyze_aaf_brief(generated_path, "GENERATED (Our Script)")
    
    print("\n" + "="*60)
    print("COMPARISON SUMMARY:")
    print("="*60)
    
    # Quick structure comparison
    try:
        with aaf2.open(reference_path, 'r') as ref_file:
            ref_mobs = list(ref_file.content.mobs)
            ref_essence = list(ref_file.content.essencedata)
        
        with aaf2.open(generated_path, 'r') as gen_file:
            gen_mobs = list(gen_file.content.mobs)
            gen_essence = list(gen_file.content.essencedata)
        
        print(f"Mob count - Reference: {len(ref_mobs)}, Generated: {len(gen_mobs)} {'✓' if len(ref_mobs) == len(gen_mobs) else '✗'}")
        print(f"Essence count - Reference: {len(ref_essence)}, Generated: {len(gen_essence)} {'✓' if len(ref_essence) == len(gen_essence) else '✗'}")
        
        # Check mob types
        ref_types = [mob.__class__.__name__ for mob in ref_mobs]
        gen_types = [mob.__class__.__name__ for mob in gen_mobs]
        
        print(f"Reference mob types: {ref_types}")
        print(f"Generated mob types: {gen_types}")
        print(f"Mob types match: {'✓' if ref_types == gen_types else '✗'}")
        
        # Overall assessment
        matches_structure = (len(ref_mobs) == len(gen_mobs) and 
                           len(ref_essence) == len(gen_essence) and
                           ref_types == gen_types)
        
        print(f"\nOVERALL STRUCTURE MATCH: {'✓ GOOD' if matches_structure else '✗ NEEDS WORK'}")
        
        return matches_structure
        
    except Exception as e:
        print(f"Error during comparison: {e}")
        return False

if __name__ == "__main__":
    compare_aafs()