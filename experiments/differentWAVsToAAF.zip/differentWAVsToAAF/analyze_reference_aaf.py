#!/usr/bin/env python3
"""
AAF Structure Analyzer
======================

Analyzes an AAF file to understand its complete structure.
"""

import aaf2
import sys
import os

def analyze_aaf_structure(aaf_path):
    """
    Analyze the complete structure of an AAF file.
    """
    print(f"Analyzing AAF: {os.path.basename(aaf_path)}")
    print("=" * 60)
    
    with aaf2.open(aaf_path, 'r') as aaf_file:
        print("HEADER INFO:")
        print(f"  Header: {aaf_file.header}")
        print()
        
        print("DICTIONARY INFO:")
        print(f"  Dictionary: {aaf_file.dictionary}")
        print()
        
        content = aaf_file.content
        print("CONTENT STORAGE:")
        print(f"  Content: {content}")
        print()
        
        # Analyze all mobs
        print("MOBS:")
        mobs = list(content.mobs)
        print(f"  Total mobs: {len(mobs)}")
        
        for i, mob in enumerate(mobs):
            print(f"\n  MOB {i+1}: {mob.__class__.__name__}")
            print(f"    Name: {mob.name}")
            print(f"    MobID: {mob.mob_id}")
            
            if hasattr(mob, 'usage'):
                print(f"    Usage: {mob.usage}")
            
            if hasattr(mob, 'descriptor') and mob.descriptor:
                desc = mob.descriptor
                print(f"    Descriptor: {desc.__class__.__name__}")
                
                # Print descriptor properties
                for key in desc.keys():
                    try:
                        value = desc[key].value
                        print(f"      {key}: {value}")
                    except:
                        print(f"      {key}: <unable to read>")
            
            # Analyze slots
            slots = list(mob.slots)
            print(f"    Slots: {len(slots)}")
            
            for j, slot in enumerate(slots):
                print(f"\n      SLOT {j+1}: {slot.__class__.__name__}")
                print(f"        Name: {slot.name}")
                print(f"        Slot ID: {slot.slot_id}")
                print(f"        Media Kind: {slot.media_kind}")
                
                if hasattr(slot, 'edit_rate'):
                    print(f"        Edit Rate: {slot.edit_rate}")
                
                if hasattr(slot, 'origin'):
                    print(f"        Origin: {slot.origin}")
                
                # Analyze segment
                if hasattr(slot, 'segment') and slot.segment:
                    seg = slot.segment
                    print(f"        Segment: {seg.__class__.__name__}")
                    
                    if hasattr(seg, 'length'):
                        print(f"          Length: {seg.length}")
                    
                    if hasattr(seg, 'start'):
                        print(f"          Start: {seg.start}")
                    
                    if hasattr(seg, 'mob_id'):
                        print(f"          References MobID: {seg.mob_id}")
                    
                    if hasattr(seg, 'slot_id'):
                        print(f"          References Slot ID: {seg.slot_id}")
        
        # Analyze essence data
        print("\n\nESSENCE DATA:")
        essence_list = list(content.essencedata)
        print(f"  Total essence data objects: {len(essence_list)}")
        
        for i, essence in enumerate(essence_list):
            print(f"\n  ESSENCE {i+1}:")
            print(f"    MobID: {essence.mob_id}")
            
            # Try to get essence info
            try:
                with essence.open('r') as stream:
                    data_size = len(stream.read())
                    print(f"    Data size: {data_size} bytes")
            except:
                print(f"    Data size: <unable to read>")

def main():
    aaf_path = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2-exportedEmbeddedAAF.aaf"
    
    if not os.path.exists(aaf_path):
        print(f"Error: File not found: {aaf_path}")
        sys.exit(1)
    
    try:
        analyze_aaf_structure(aaf_path)
    except Exception as e:
        print(f"Error analyzing AAF: {e}")
        import traceback
        traceback.print_exc()

if __name__ == "__main__":
    main()