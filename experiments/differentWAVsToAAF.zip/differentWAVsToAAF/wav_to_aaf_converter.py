#!/usr/bin/env python3
"""
WAV to AAF Converter for Media Composer
========================================

This script converts a WAV file into an embedded AAF file that can be imported 
into Avid Media Composer. The script prompts for the WAV file input and creates 
the AAF file with the same name in the same directory.

Requirements:
- pyaaf2 library
- Python 3.6+

Usage:
    python wav_to_aaf_converter.py

The script will:
1. Prompt for a WAV file selection
2. Create an AAF file with embedded audio
3. Save the AAF in the same directory as the source WAV
4. Create proper Media Composer compatible structure with:
   - Master Mob
   - Source Mob  
   - Timeline slots
   - Embedded essence data

Author: Auto-generated script for WAV to AAF conversion
"""

import os
import sys
import tkinter as tk
from tkinter import filedialog, messagebox
import wave
import aaf2

def get_wav_info(wav_path):
    """
    Extract audio information from WAV file.
    
    Args:
        wav_path (str): Path to the WAV file
        
    Returns:
        dict: Dictionary containing audio properties
    """
    try:
        with wave.open(wav_path, 'rb') as wav_file:
            return {
                'channels': wav_file.getnchannels(),
                'sample_width': wav_file.getsampwidth(),
                'sample_rate': wav_file.getframerate(),
                'frame_count': wav_file.getnframes(),
                'frames': wav_file.getnframes(),  # alias for compatibility
                'duration_seconds': wav_file.getnframes() / wav_file.getframerate()
            }
    except Exception as e:
        raise Exception(f"Error reading WAV file: {e}")

def select_wav_file():
    """
    Open a file dialog to select a WAV file.
    
    Returns:
        str: Path to selected WAV file, or None if cancelled
    """
    # Hide the main tkinter window
    root = tk.Tk()
    root.withdraw()
    
    # File dialog for WAV selection
    wav_file = filedialog.askopenfilename(
        title="Select WAV file to convert to AAF",
        filetypes=[
            ("WAV files", "*.wav"),
            ("All files", "*.*")
        ]
    )
    
    root.destroy()
    return wav_file if wav_file else None

def create_aaf_from_wav(wav_path, aaf_path):
    """
    Create AAF compatible with Media Composer 2025.6.0.
    Newer MC versions require specific AAF structure and metadata.
    
    Args:
        wav_path (str): Path to source WAV file
        aaf_path (str): Path for output AAF file
    """
    print(f"Converting {os.path.basename(wav_path)} to AAF...")
    print("Targeting Media Composer 2025.6.0 compatibility...")
    
    # Get WAV file information
    wav_info = get_wav_info(wav_path)
    print(f"WAV Info: {wav_info['channels']} channels, {wav_info['sample_rate']} Hz, "
          f"{wav_info['duration_seconds']:.2f} seconds")
    
    # Create new AAF file with MC 2025 compatible settings
    with aaf2.open(aaf_path, 'w') as aaf_file:
        
        master_mob_name = os.path.splitext(os.path.basename(wav_path))[0]
        
        print("Creating MC 2025.6.0 compatible AAF...")
        
        # Use 23.976 fps (most common in modern post-production)
        edit_rate = 23.976
        
        # Create Master Mob with full descriptive name
        master_mob = aaf_file.create.MasterMob(f"{master_mob_name}_Master")
        aaf_file.content.mobs.append(master_mob)
        
        # Try different import approaches for newer MC compatibility
        try:
            # Approach 1: Try with specific edit rate first
            master_mob.import_audio_essence(wav_path, edit_rate=edit_rate)
            print(f"✓ Audio imported with {edit_rate} fps")
            
        except Exception as e:
            print(f"23.976 fps failed: {e}")
            try:
                # Clear and try with 29.97 fps (broadcast standard)
                aaf_file.content.mobs.clear()
                aaf_file.content.essencedata.clear()
                
                master_mob = aaf_file.create.MasterMob(f"{master_mob_name}_Master")
                aaf_file.content.mobs.append(master_mob)
                master_mob.import_audio_essence(wav_path, edit_rate=29.97)
                edit_rate = 29.97
                print(f"✓ Audio imported with {edit_rate} fps")
                
            except Exception as e2:
                print(f"All frame rates failed: {e2}")
                return
        
        # Add additional metadata that MC 2025 might expect
        try:
            # Set product info for newer MC compatibility
            aaf_file.header['ProductName'] = "WAV to AAF Converter"
            aaf_file.header['ProductVersion'] = "1.0"
            aaf_file.header['Platform'] = "macOS"
            print("✓ Added MC 2025 compatible metadata")
        except Exception as e:
            print(f"Metadata addition failed (non-critical): {e}")
        
        print(f"✓ MC 2025 compatible AAF created")
        print(f"  Mobs: {len(aaf_file.content.mobs)}")
        print(f"  Essence: {len(aaf_file.content.essencedata)}")
        print(f"  Edit rate: {edit_rate} fps")
        print(f"  Master Mob: {master_mob.name}")
        
        print(f"AAF file created: {aaf_path}")
        print("Ready for import into Media Composer 2025.6.0")

def main():
    """
    Main function to run the WAV to AAF converter.
    """
    print("WAV to AAF Converter for Media Composer")
    print("=" * 50)
    
    try:
        # Check if pyaaf2 is available
        import aaf2
        print("pyaaf2 library found ✓")
    except ImportError:
        print("ERROR: pyaaf2 library not found!")
        print("Please install it using: pip install pyaaf2")
        sys.exit(1)
    
    # Temporarily hardcoded for testing iterations
    wav_file = "/Users/jasonbrodkey/Documents/SFX/Test Source Files/wavTest/RockScrape 6040_75_2.wav"
    
    # Skip file selection dialog for now
    print(f"Using hardcoded test file: {os.path.basename(wav_file)}")
    
    # # Select WAV file
    # print("\nSelect WAV file to convert...")
    # wav_file = select_wav_file()
    
    # if not wav_file:
    #     print("No file selected. Exiting.")
    #     return
    
    if not os.path.exists(wav_file):
        print(f"ERROR: File not found: {wav_file}")
        return
    
    if not wav_file.lower().endswith('.wav'):
        print("ERROR: Selected file is not a WAV file.")
        return
    
    # Generate AAF filename
    wav_dir = os.path.dirname(wav_file)
    wav_name = os.path.splitext(os.path.basename(wav_file))[0]
    aaf_file = os.path.join(wav_dir, f"{wav_name}.aaf")
    
    # Check if AAF file already exists - auto overwrite for testing
    if os.path.exists(aaf_file):
        print(f"Overwriting existing AAF: {os.path.basename(aaf_file)}")
    
    # # Check if AAF file already exists
    # if os.path.exists(aaf_file):
    #     root = tk.Tk()
    #     root.withdraw()
    #     
    #     result = messagebox.askyesno(
    #         "File Exists", 
    #         f"AAF file already exists:\n{aaf_file}\n\nOverwrite?"
    #     )
    #     
    #     root.destroy()
    #     
    #     if not result:
    #         print("Conversion cancelled.")
    #         return
    
    try:
        # Convert WAV to AAF
        create_aaf_from_wav(wav_file, aaf_file)
        
        # Show success message - simplified for testing
        print("Conversion completed successfully!")
        print(f"Output: {os.path.basename(aaf_file)}")
        
        # # Show success message
        # root = tk.Tk()
        # root.withdraw()
        # 
        # messagebox.showinfo(
        #     "Conversion Complete",
        #     f"WAV file successfully converted to AAF!\n\n"
        #     f"Input: {os.path.basename(wav_file)}\n"
        #     f"Output: {os.path.basename(aaf_file)}\n\n"
        #     f"The AAF file can now be imported into Media Composer."
        # )
        # 
        # root.destroy()
        
    except Exception as e:
        print(f"ERROR: Conversion failed: {e}")
        print(f"Error details: {type(e).__name__}")
        import traceback
        traceback.print_exc()
        
        # # Show error dialog
        # root = tk.Tk()
        # root.withdraw()
        # 
        # messagebox.showerror(
        #     "Conversion Error",
        #     f"Failed to convert WAV to AAF:\n\n{str(e)}"
        # )
        # 
        # root.destroy()
        # sys.exit(1)

if __name__ == "__main__":
    main()