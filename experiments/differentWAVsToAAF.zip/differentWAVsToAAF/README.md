# WAV to AAF Converter

A Python script that converts WAV audio files into AAF (Advanced Authoring Format) files that can be imported directly into Avid Media Composer.

## Features

- **User-friendly GUI**: File dialog for easy WAV file selection
- **Embedded Essence**: Creates AAF files with embedded audio data (no external file dependencies)
- **Media Composer Compatible**: Generates proper AAF structure with Master Mob, Source Mob, and timeline slots
- **Multi-channel Support**: Handles mono, stereo, and multi-channel audio files
- **Automatic Naming**: Output AAF file is automatically named after the input WAV file
- **Same Directory Output**: AAF file is created in the same location as the source WAV

## Requirements

- Python 3.6 or later
- pyaaf2 library
- tkinter (usually included with Python)

## Installation

### Quick Setup (macOS/Linux)
```bash
chmod +x setup.sh
./setup.sh
```

### Manual Installation
```bash
pip3 install pyaaf2
```

## Usage

### Run the Script
```bash
python3 wav_to_aaf_converter.py
```

### Steps
1. Run the script
2. Select your WAV file using the file dialog
3. The script will automatically:
   - Analyze the WAV file (channels, sample rate, duration)
   - Create an AAF file with the same name
   - Embed the audio essence
   - Create proper Media Composer structure
4. Import the resulting AAF file into Media Composer

## Technical Details

### AAF Structure Created
- **Master Mob**: Main composition container
- **Source Mob**: Contains the embedded audio essence
- **Timeline Slots**: One slot per audio channel
- **Tape Mob**: Provides timecode reference (starting at 01:00:00:00)

### Audio Support
- **Formats**: WAV files (PCM audio)
- **Channels**: Mono, stereo, and multi-channel
- **Sample Rates**: All standard rates supported by WAV format
- **Bit Depths**: 16-bit, 24-bit, 32-bit

### Edit Rate
The script uses 25 fps as the default edit rate (PAL standard). This can be modified in the script if needed for different project requirements.

## Example

```
Input:  /path/to/audio/my_sound_effect.wav
Output: /path/to/audio/my_sound_effect.aaf
```

The AAF file will contain:
- Embedded audio essence from the WAV file
- Proper timeline structure for Media Composer
- Timecode starting at 01:00:00:00
- One audio track per channel in the source WAV

## Troubleshooting

### Common Issues

1. **"pyaaf2 library not found"**
   - Run: `pip3 install pyaaf2`

2. **"No module named tkinter"**
   - On Ubuntu/Debian: `sudo apt-get install python3-tk`
   - On macOS: tkinter should be included with Python

3. **File permission errors**
   - Ensure you have write permissions to the directory containing the WAV file

### Media Composer Import

1. Open Media Composer
2. Go to File > Import
3. Select the generated AAF file
4. The audio will appear in your project with proper timeline structure

## Script Details

The script performs the following operations:

1. **File Selection**: Uses tkinter file dialog for user-friendly file selection
2. **WAV Analysis**: Reads WAV header to determine channels, sample rate, and duration
3. **AAF Creation**: Creates new AAF file with proper structure:
   - Master Mob as main container
   - Source Mob with embedded essence
   - Timeline slots for each audio channel
   - Tape Mob for timecode reference
4. **Essence Embedding**: Uses pyaaf2's `import_audio_essence()` to embed the WAV data
5. **Error Handling**: Comprehensive error checking and user feedback

## License

This script is provided as-is for converting WAV files to AAF format for use with Avid Media Composer.

## Notes

- The generated AAF files are self-contained (embedded essence)
- Compatible with Avid Media Composer and other AAF-supporting applications
- Maintains original audio quality and metadata
- Timecode starts at 01:00:00:00 by default (professional standard)